Folder that holds all the mud configuration

## Folder structure
### hud
Heads Up Display configuration.
* HUD Commands

### map
All map and positioning related configuration.

### player
Player character configuration. All player related information will be handled from here.
* Player character variables structure
* Player events

### sys 
System configuration.
* System events
* Commands

### *main.tin*
Main configuration file. This is the configuration file that will be loaded inititally, and from here all the rest of the configuration

