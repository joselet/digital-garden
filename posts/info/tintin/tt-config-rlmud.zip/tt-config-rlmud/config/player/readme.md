Configuration related to the player characteristics.

## Structure
### alias.tin
Common aliases for all the chars no matter class, race, etc.

### cmds.tin
Basic player commands:
* /player
* /player_help

### events.tin
Events related to the player. Currently implented:
* enter_mud: for when the character enters the mud
* score_update: when the player score has been updated (life, xp, etc)

### life.tin
Life related configuration, like hps triggers, etc.