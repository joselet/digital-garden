#!/bin/bash

FICH=$1.tin
echo "#class {RL_PLAYER_SPELLS_ARCANE_$1} {kill}" > $FICH
echo "#class {RL_PLAYER_SPELLS_ARCANE_$1} {open}" >> $FICH
echo >> $FICH
echo "#class {RL_PLAYER_SPELLS_ARCANE_$1} {close}" >> $FICH

echo "Spell '$1' created."
