Folder holding system configuration

## Structure
### cmds.tin
Various system commands that will be used through the config

### default.tin
Default configuration for Tintin++ (the one that is set when you type #config)
