Configuration related to the Heads Up Display.

## Structure
### cmds.tin
Cmds for handling the HUD
* /hud
* /hud_display
* /hud_help
* /hud_prepare

