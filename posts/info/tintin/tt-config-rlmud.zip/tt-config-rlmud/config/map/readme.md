Map configuration

## Folder structure
### cmds.tin
Map related commands.

### pois.tin
Configuration for points of interest.