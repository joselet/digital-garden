# Tintin++ configuration for Reinos de Leyenda MUD
This is a set of scripts and configurations for playing Reinos de Leyenda MUD (https://www.reinosdeleyenda.es/)

Some ideas and configurations have been taken from Dunkelheit's configuration for RL: https://github.com/dunkelheit/rl-plus-plus

## Folder structure
### config 
Folder that has all the configuration scripts 
### output 
Empty folder where all the generated files will be stored
### *display_map.sh* 
Script that read the map output and displays it. Useful for playing with an additional window to display the map at the same time
### *run.sh* 
Main script that runs Tintin++ witht this configuration
