#!/bin/bash

CFGDIR=config
CFGMAIN=main.tin

# We do this to make the pwd for tintin++ the one with the config
PWD=`pwd`
cd $CFGDIR
tt++ -r $CFGMAIN
cd $PWD
